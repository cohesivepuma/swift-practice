import Foundation
var weightOfWeek=[70.6, 70.5, 71.2, 68.3, 70.9, 69.1, 70.0]
var weightOfDay=["星期一","星期二","星期三","星期四","星期五","星期六","星期日"]
var number:Int
number=0
for dateOfSth in weightOfWeek{
    if(dateOfSth>=70.0){
        print(weightOfDay[number])
    }
    number+=1
}
