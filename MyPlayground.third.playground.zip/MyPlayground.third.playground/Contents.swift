import Foundation

struct Player{
    static var allPlayers:[Player]=[]
    var name:String
    var livigRemain = 5{
        willSet{
            print("warning!only \(newValue) remainlive")
        }
        didSet{
            if livigRemain != 0{
                print("continue!")
            }
            else{
                print("game over!")
            }
        }
    }
    var isPlayerOutOfLives:Bool{
        get{
            livigRemain>0 ? false:true
        }
        set{
            if newValue{
                livigRemain = 0
            }
        }
    }
    let maxHealth = 100
    lazy var currentHealth = maxHealth//lazy延迟初始化
    init(name: String, livigRemain: Int = 5 , currentHealth : Int) {//自定义初始化
        self.name = name
        self.livigRemain = livigRemain
        self.currentHealth = currentHealth
    }
    init(name : String , livigRemain : Int) {
        self.name = "VIP" + name
        self.livigRemain = livigRemain
        currentHealth = 10000
    }
    init(name:String){
        self.name = name
    }
    
    func welcomePlyer(){
        print("\(name),Welcome to this game")
    }
    
    mutating func damaged(by health : Int){
        currentHealth -= health
        //如过currenetHealth为0，生命值减一
        if livigRemain>0 && currentHealth<0{
            livigRemain-=1
            currentHealth=maxHealth+currentHealth
        }
        if livigRemain==0{
            print("Game Over")
        }
    }
    
    mutating func stateReport(){
        //这里没加mutating出错了
        print("Your livingRemain is \(livigRemain),Your currentHealth is \(currentHealth)")
    }
    static func recentAddedPlayer() -> Player{
        allPlayers[allPlayers.count-1]
    }
}

var playerWang = Player(name: "Wang")
/*
playerWang.name
playerWang.welcomePlyer()
playerWang.damaged(by: 50)
playerWang.stateReport()
playerWang.damaged(by: 60)
playerWang.stateReport()
playerWang.damaged(by: 70)
playerWang.stateReport()
playerWang.damaged(by: 20)
playerWang.stateReport()
playerWang.isPlayerOutOfLives = true
*/
print("\(playerWang.name) and \(playerWang.currentHealth)")
var playerGu = Player(name: "Gu",livigRemain: 10)
print("\(playerGu.name) and \(playerGu.currentHealth)")
Player.allPlayers.append(contentsOf: [playerWang,playerGu])
print("new is \(Player.recentAddedPlayer().name)")
