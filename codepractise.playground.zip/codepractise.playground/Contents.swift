import Foundation

let introduction = "hello worker"//输出文字

var waterBottle:Int
waterBottle = 0
waterBottle=waterBottle+1
waterBottle+=1
if(5/3>1.5 && !("ab"=="abc"))
{
    print("4.yes")
}
let toDay=5
let newOut="星期\(toDay),快放假了"//remember it's \

//func

func sayHi(){
    print("hi")
}
sayHi()
func testSomething(_ direction:String,and meter:Int){
    print("向\(direction)进，\(meter)米")
}
let forward="前"
let meters=100
testSomething(forward, and: meters)
func rollDice() -> Int{
    let randomNumberOfDice=Int.random(in: 1...6)
    return randomNumberOfDice
}
print(rollDice())
func isArrivedAtHome(_ distanceToHome:Int)->Bool{
    distanceToHome < 5 ? true :false
}
if(isArrivedAtHome(3)){
    print("At home")
}
//如果直接加数字的话需要在函数里加上（_ label）
//或是使用参数标签（sth label）
func add(_ a:Double,_ b:Double)->Double{
    return a+b
}
print("the result is \(Int(add(3.2, 1.6)))")
//强制转换type(number)

//array and loop

var weightRecordA = [70.5,70,69.9,69.5,69.5]
var weightRecordB : [Double]=[]//没数组记得加类型
weightRecordA.append(69.1)//数组后面加数据
weightRecordA+=[69.0,68.9]//加多个数据
weightRecordA.insert(70.4, at: 2)//插入数据
weightRecordA.remove(at:2)//移除数据
let weightOfThirdDay=weightRecordA[2]//使用数据
let weightOfRandom = weightRecordA.randomElement()//随机抽取数据
let indexOne = weightRecordA.firstIndex(of: 70.5)//查找数据位置
weightRecordA[5] = 70.0//修改数据
weightRecordA.sort()//排序
weightRecordA.shuffle()//打散
let averageWeight=70.0
let weightDiff = weightRecordA.map{$0-averageWeight}//取差值 map（映射）
print(weightDiff)
let aboveSeventy=weightRecordA.filter{$0>70}//选值加入新数组 filter（筛选）
//more about https://developer.apple.com/documentation/swift/array
let menu=[
    ["milk","apple"],
    ["orange","juice"],
    ["pie","penapple"]
]
print(menu[2][0])

//Dictionary https://developer.apple.com/documentation/swift/dictionary

let phoneBookA:[String:Int]=[:]
let phoneBookB=["jack":114,"lucy":514]
var phoneBook:[String:Int]=[:]
phoneBook["lili"]=1919
phoneBook["wang"]=810
phoneBook["gu"]=114
print(phoneBook)
phoneBook["lili"]=nil
print(phoneBook)
let numberOfWang = phoneBook["wang"]
phoneBook["wang"]=114514
print(phoneBook)

//combine array and dictionary
let dailyMenu = [
        "早餐":["egg","bread"],
        "午餐":["chilken","beef"],
        "晚餐":["milk","toufu"]
]
print(dailyMenu["早餐"] as Any )//这里为什么要加as any？

//loop

let enrolledPeople=["lucy","lili","jack"]
for people in enrolledPeople{
    print("Welcome \(people)")
}
for _ in 1...5{
    waterBottle+=1
}
while waterBottle<10{
    waterBottle+=1
}
print(waterBottle)
//repeat while as same as do while
